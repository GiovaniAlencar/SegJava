public abstract class Cliente {
	public String cliente;
	public float valor_imovel;
	public float seguro;
	public String endereco;
	public int zona;
	public int tipo;
	public int numero_funcionarios;
	public int numero_visitas;
	public int ramo;

}
